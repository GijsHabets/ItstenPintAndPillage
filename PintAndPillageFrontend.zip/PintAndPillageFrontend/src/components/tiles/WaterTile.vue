<template>
    <div>
        <img class="tileImg" src="../../assets/tiles/water_spot.png"/>
    </div>
</template>

<script>
</script>

<style>
</style>
