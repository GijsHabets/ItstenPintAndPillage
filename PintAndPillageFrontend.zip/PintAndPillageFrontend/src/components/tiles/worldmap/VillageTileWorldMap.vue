<template>
    <div class="villageTile">
        <img src="../../../assets/worldmap/Village.png"/>
    </div>
</template>

<script>
    /* eslint-disable no-console */

    export default{}
</script>
