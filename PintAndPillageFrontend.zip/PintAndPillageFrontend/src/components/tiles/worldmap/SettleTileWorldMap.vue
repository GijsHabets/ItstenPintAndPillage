<template>
    <div class="SettleTile">
        <img src="../../../assets/worldmap/SettleIconWorldMap.png"/>
    </div>
</template>

<script>
    /* eslint-disable no-console */

    export default{}
</script>

<style lang="scss" scoped>
    .SettleTile{
        cursor: pointer;
        img{
            width: 40px;
            height: 40px;
        }
    }
</style>
